@extends('layouts.app')

@section('title', 'Home')

@php
    $showHero = true;
@endphp

@section('content')
    <!-- Your page content here -->
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2>Welcome to our homepage</h2>
                <!-- Add your content here -->
            </div>
        </div>
    </div>
@endsection 